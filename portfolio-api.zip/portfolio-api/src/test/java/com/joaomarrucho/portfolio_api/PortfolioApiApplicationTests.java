package com.joaomarrucho.portfolio_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortfolioApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
